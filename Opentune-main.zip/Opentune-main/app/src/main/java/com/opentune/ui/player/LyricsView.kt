package com.opentune.ui.player

import androidx.compose.animation.togetherWith

import androidx.compose.foundation.layout.widthIn

import androidx.compose.foundation.border

import androidx.compose.ui.draw.shadow

import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.FormatQuote
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.IosShare
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import com.opentune.ui.theme.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import com.opentune.ui.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.dp
import com.opentune.data.lyrics.LyricGap
import com.opentune.data.lyrics.LyricLine
import com.opentune.data.lyrics.LyricWord
import com.opentune.data.lyrics.Romanizer
import com.opentune.data.lyrics.instrumentalGaps
import com.opentune.data.lyrics.VOICE_SECOND
import com.opentune.data.lyrics.VOICE_TOGETHER
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.opentune.data.lyrics.Lyrics
import com.opentune.ui.LyricsState
import com.opentune.ui.components.MessageState
import com.opentune.ui.components.Placeholder
import com.opentune.ui.theme.LyricsTextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.rememberTextMeasurer
import com.opentune.data.settings.LyricsAnimation
import androidx.compose.runtime.collectAsState
import com.opentune.data.settings.AppSettings
import com.opentune.data.settings.LyricsAlign
import kotlin.math.abs
import kotlinx.coroutines.delay

@Composable
fun LyricsView(
    state: LyricsState,
    position: () -> Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
    synced: Boolean = true,
    blur: Boolean = true,
    /** Long-press on a line: it's being sung now, so the song's lyrics move to match. */
    onSyncLine: ((Long) -> Unit)? = null,
    /** The song, for sharing its lines as a lyric card; no share button without it. */
    shareSong: com.opentune.data.model.Song? = null,
    /** The intent to play (true through a buffer stall), so the sync clock coasts rather than snapping back. */
    playing: () -> Boolean = { true },
    /** Rises on each seek or skip, so the sync clock takes those jumps cleanly. */
    seeks: () -> Long = { 0L },
    /** Follow the player's existing focus timer and touch-to-reveal controls. */
    controlsVisible: Boolean = true,
) {
    // The song and its lines as they were when sharing began, so a song
    // change while the sheet is open can't mix one song's words with another's.
    var sharing by remember { mutableStateOf<Pair<com.opentune.data.model.Song, List<String>>?>(null) }
    var shareStartAt by remember { mutableStateOf(-1) }
    // Synced lines picked for a lyric card, by index; picking starts with a
    // long press on a line (or the share button) and ends with Cancel or Share.
    val syncedLines = ((state as? LyricsState.Found)?.lyrics as? Lyrics.Synced)?.lines
    val selection = remember(syncedLines) { androidx.compose.runtime.mutableStateListOf<Int>() }
    // The picked lines handed to the card sheet, frozen when Share was pressed.
    var sharingPicked by remember { mutableStateOf<Pair<com.opentune.data.model.Song, List<String>>?>(null) }
    Box(modifier) {
        when (state) {
            is LyricsState.Loading -> Column(Modifier.padding(top = 20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                SettingUpBadge()
                listOf(0.8f, 0.6f, 0.9f, 0.5f, 0.7f).forEach {
                    Placeholder(Modifier.fillMaxWidth(it).height(28.dp), MaterialTheme.shapes.small)
                }
            }
            is LyricsState.NotFound -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                MessageState(Icons.Rounded.Lyrics, "No lyrics for this one", message = "None of your lyrics sources has this track yet. You can change them in Settings › Lyrics sources.")
            }
            is LyricsState.Found -> when (val lyrics = state.lyrics) {
                is Lyrics.Synced ->
                    if (synced) SyncedLyrics(
                        lyrics.lines, position, onSeek, blur, lyrics.source, onSyncLine, playing, seeks,
                        selection = selection.takeIf { shareSong != null },
                        onShareSelection = shareSong?.let { song ->
                            {
                                val picked = selection.sorted().mapNotNull { lyrics.lines.getOrNull(it)?.text?.trim()?.takeIf(String::isNotEmpty) }
                                if (picked.isNotEmpty()) sharingPicked = song to picked
                                selection.clear()
                            }
                        },
                    )
                    else PlainLyrics(lyrics.lines.joinToString("\n") { it.text }, lyrics.source, note = null)
                is Lyrics.Plain -> PlainLyrics(lyrics.text, lyrics.source)
            }
        }
        val found = (state as? LyricsState.Found)?.lyrics
        if (found != null) {
            val haptics = com.opentune.ui.components.rememberHaptics()
            AnimatedVisibility(
                visible = controlsVisible,
                enter = fadeIn(tween(220)),
                exit = fadeOut(tween(360)),
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 4.dp),
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    // Turn romanized lines (Latin letters under another script) on or off from the page.
                    if (found is Lyrics.Synced && Romanizer.available) {
                        val romanizeOn = AppSettings.lyrics.collectAsState().value.romanize
                        LyricActionButton(Icons.Rounded.Translate, if (romanizeOn) "Turn off romanization" else "Show romanized lyrics", active = romanizeOn) {
                            haptics.tick()
                            AppSettings.updateLyrics { it.copy(romanize = !it.romanize) }
                        }
                    }
                    if (shareSong != null) {
                        // Lines with words in them (synced lyrics carry empty ones for the gaps), with
                        // their start times so the sheet can open on the line being sung.
                        val timed = remember(found) {
                            when (found) {
                                is Lyrics.Synced -> found.lines.filter { it.text.isNotBlank() }.map { it.text.trim() to it.startMs }
                                is Lyrics.Plain -> found.text.lines().map { it.trim() }.filter { it.isNotEmpty() }.map { it to -1L }
                            }
                        }
                        val lines = remember(timed) { timed.map { it.first } }
                        LyricActionButton(Icons.Rounded.FormatQuote, "Share lyrics") {
                            haptics.tick()
                            val now = position()
                            if (found is Lyrics.Synced && synced) {
                                // Start picking on the page itself, from the line being sung.
                                selection.clear()
                                selection.add(found.lines.indexOfLast { it.startMs <= now }.coerceAtLeast(0))
                            } else {
                                shareStartAt = if (found is Lyrics.Synced) timed.indexOfLast { it.second <= now } else -1
                                sharing = shareSong to lines
                            }
                        }
                    }
                }
            }
        }
        // The action row may hide while the sheet is open; keep the sheet independent.
        sharing?.let { (song, shared) -> com.opentune.ui.share.LyricCardSheet(song, shared, startAt = shareStartAt, onDismiss = { sharing = null }) }
        sharingPicked?.let { (song, picked) ->
            com.opentune.ui.share.LyricCardSheet(song, picked, startAt = 0, onDismiss = { sharingPicked = null }, pickable = false)
        }
    }
}

/**
 * The pill floating over the lyrics while lines are being picked for a card: a
 * close button, how many lines are picked (or what to do when none are), and
 * Share in the accent, lit once there's something to share.
 */
@Composable
internal fun SelectionBar(count: Int, onCancel: () -> Unit, onShare: () -> Unit, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val pill = RoundedCornerShape(32.dp)
    val ready = count > 0
    val shareFill by androidx.compose.animation.animateColorAsState(
        if (ready) scheme.primary else Color.White.copy(alpha = 0.12f), tween(220), label = "shareFill",
    )
    val shareInk by androidx.compose.animation.animateColorAsState(
        if (ready) scheme.onPrimary else Color.White.copy(alpha = 0.45f), tween(220), label = "shareInk",
    )
    Row(
        modifier
            .widthIn(max = 440.dp)
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .shadow(24.dp, pill, clip = false, ambientColor = Color.Black.copy(alpha = 0.5f), spotColor = Color.Black.copy(alpha = 0.5f))
            .clip(pill)
            .background(Color(0xEB16161A))
            .border(1.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.18f), Color.White.copy(alpha = 0.04f))), pill)
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)).clickable(onClick = onCancel),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Close, com.opentune.ui.theme.tr("Cancel"), tint = Color.White, modifier = Modifier.size(22.dp)) }
        androidx.compose.animation.AnimatedContent(
            targetState = count,
            transitionSpec = {
                val up = targetState > initialState
                (androidx.compose.animation.slideInVertically { if (up) it / 2 else -it / 2 } + fadeIn(tween(180)))
                    .togetherWith(androidx.compose.animation.slideOutVertically { if (up) -it / 2 else it / 2 } + fadeOut(tween(140)))
            },
            label = "pickedCount",
            modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
        ) { n ->
            Column {
                Text(
                    when (n) { 0 -> "Pick lines"; 1 -> "1 line selected"; else -> com.opentune.i18n.Tr.f("{0} lines selected", n) },
                    color = Color.White, style = MaterialTheme.typography.titleSmall,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, maxLines = 1,
                )
                Text(
                    if (n == 0) "Tap the lines to share" else "Tap a line again to leave it out",
                    color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall, maxLines = 1,
                )
            }
        }
        Row(
            Modifier.height(48.dp).clip(RoundedCornerShape(24.dp)).background(shareFill)
                .clickable(enabled = ready, onClick = onShare).padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.IosShare, null, tint = shareInk, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(com.opentune.ui.theme.tr("Share"), color = shareInk, style = MaterialTheme.typography.titleSmall,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        }
    }
}

/** A round translucent button on the lyrics page (romanize, share). Tinted when its state is on. */
@Composable
private fun LyricActionButton(icon: ImageVector, description: String, active: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .background(if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, Modifier.size(20.dp), tint = if (active) MaterialTheme.colorScheme.primary else LocalContentColor.current)
    }
}

@Composable
private fun PlainLyrics(text: String, source: String, note: String? = "These lyrics aren't synced to the music.") {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 24.dp)) {
        if (note != null) {
            Text(
                note,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp),
            )
        }
        val style = lyricsStyle()
        val romanize = AppSettings.lyrics.collectAsState().value.romanize
        val romanized by androidx.compose.runtime.produceState<List<String?>>(emptyList(), text, romanize) {
            if (!romanize) { value = emptyList(); return@produceState }
            val texts = text.lines()
            value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { Romanizer.lines(texts) }
            // Japanese with kanji: the offline reading first, then the full one when it arrives.
            if (com.opentune.data.lyrics.JapaneseReadings.wanted(texts)) {
                com.opentune.data.lyrics.JapaneseReadings.lines(texts)?.let { read -> value = read.mapIndexed { i, r -> r ?: value.getOrNull(i) } }
            }
        }
        val dimmed = MaterialTheme.colorScheme.onSurfaceVariant
        val shown = remember(text, romanized, dimmed) {
            if (romanized.none { it != null }) AnnotatedString(text) else buildAnnotatedString {
                text.lines().forEachIndexed { i, line ->
                    if (i > 0) append("\n")
                    append(line)
                    romanized.getOrNull(i)?.let { r ->
                        append("\n")
                        withStyle(SpanStyle(color = dimmed, fontSize = style.fontSize * 0.5f)) { append(r) }
                    }
                }
            }
        }
        Text(shown, Modifier.fillMaxWidth(), style = style.copy(fontSize = style.fontSize * 0.8f, lineHeight = style.lineHeight * 0.85f))
        Credit(source)
    }
}

/**
 * Line-by-line lyrics that follow the music. The current line is bright and
 * full size and its words light up as they're sung; the rest are dimmed,
 * slightly smaller and (on Android 12+) softly blurred by distance. The list
 * glides to keep the current line about a third of the way down. Scrolling by
 * hand pauses that for a few seconds; tapping a line jumps the song there.
 */
@Composable
private fun SyncedLyrics(
    lines: List<LyricLine>,
    position: () -> Long,
    onSeek: (Long) -> Unit,
    blur: Boolean,
    source: String,
    onSyncLine: ((Long) -> Unit)? = null,
    playing: () -> Boolean = { true },
    seeks: () -> Long = { 0L },
    /** Lines picked for a lyric card, by index; null where there's no song to share. */
    selection: androidx.compose.runtime.snapshots.SnapshotStateList<Int>? = null,
    onShareSelection: (() -> Unit)? = null,
) {
    val ui by AppSettings.ui.collectAsState()
    val reduced = ui.reduceAnimation || !android.animation.ValueAnimator.areAnimatorsEnabled()
    val animation = if (reduced) LyricsAnimation.MINIMAL else ui.lyricsAnimation
    val listState = rememberLazyListState()
    val selecting = selection?.isNotEmpty() == true
    val haptics = com.opentune.ui.components.rememberHaptics()
    androidx.activity.compose.BackHandler(enabled = selecting) { selection?.clear() }
    val romanize = AppSettings.lyrics.collectAsState().value.romanize
    val romanized by androidx.compose.runtime.produceState<List<String?>>(emptyList(), lines, romanize) {
        if (!romanize) { value = emptyList(); return@produceState }
        val texts = lines.map { it.text }
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { Romanizer.lines(texts) }
        // Japanese with kanji: the offline reading first, then the full one when it arrives.
        if (com.opentune.data.lyrics.JapaneseReadings.wanted(texts)) {
            com.opentune.data.lyrics.JapaneseReadings.lines(texts)?.let { read -> value = read.mapIndexed { i, r -> r ?: value.getOrNull(i) } }
        }
    }
    // Two singers trade lines: the second voice's sit on the other side.
    val duet = remember(lines) { lines.any { it.voice == VOICE_SECOND } }
    // A clock steered by the player's readings: it never moves the words back
    // without an announced seek, so a word just sung can't count as unsung and
    // play its motion twice, and it coasts through a buffer stall rather than
    // snapping back. Restarts for each new set of lines (a new song).
    val clock = rememberLyricsClock(position, playing, seeks, trackKey = lines)
    val pos by rememberUpdatedState(clock)
    // The lines with instrumental breaks folded in: a long stretch with no
    // singing becomes a row of breathing dots, so the last sung line doesn't
    // sit lit through a passage with no vocals.
    val rows = remember(lines) { buildLyricRows(lines) }
    // A line lights a moment before its timestamp, so it's there as the singer
    // starts it; a gap's dots take over the moment the singing stops.
    val activeRow by remember(rows) {
        derivedStateOf {
            val p = pos() + LINE_LEAD_MS
            var found = -1
            rows.forEachIndexed { i, row -> if (row.startMs <= p) found = i }
            found
        }
    }
    // The line the view is centred on, whether a line or the gap after it is lit.
    val activeLine by remember(rows) { derivedStateOf { (rows.getOrNull(activeRow) as? LyricRow.Line)?.index ?: (rows.getOrNull(activeRow) as? LyricRow.Gap)?.gap?.afterIndex ?: -1 } }
    // Where the list is heading: the next row, from a moment before it's due. The glide
    // takes that moment, so a line arrives in place as it's sung rather than chasing it.
    val leadRow by remember(rows) {
        derivedStateOf {
            val current = activeRow
            val next = rows.getOrNull(current + 1)
            if (next == null) current
            else if (pos() + LINE_LEAD_MS + glideMs(rows, current) >= next.startMs) current + 1
            else current
        }
    }
    var following by remember { mutableStateOf(true) }
    var glideRun by remember(rows) { mutableStateOf<GlideRun?>(null) }
    val elapsed = remember(rows) { androidx.compose.runtime.mutableFloatStateOf(0f) }

    // A drag means the listener wants to look around. Watching drags rather
    // than any scrolling tells theirs from the glide below, even when a drag
    // cuts into a glide that's under way.
    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect { if (it is DragInteraction.Start) following = false }
    }
    // While lines are being picked the list holds still under the finger.
    LaunchedEffect(selecting) { if (selecting) following = false }
    LaunchedEffect(following, listState.isScrollInProgress, selecting) {
        if (!following && !listState.isScrollInProgress && !selecting) {
            delay(RESUME_FOLLOW_MS)
            following = true
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // The current line sits near the top, leaving room for just the line before it.
        val anchor = maxHeight * LINE_ANCHOR
        LaunchedEffect(leadRow, following, reduced) {
            if (!following) {
                // A hand on the list stops the glide where it is; its trail goes with it.
                glideRun = null
                return@LaunchedEffect
            }
            // +1 for the intro item ahead of the first line.
            val index = (leadRow + 1).coerceAtLeast(0)
            val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
            if (reduced || item == null) {
                // Off screen (a seek, a long scroll away) or motion off: straight there.
                glideRun = null
                listState.scrollToItem(index)
                return@LaunchedEffect
            }
            if (abs(item.offset) < 1) return@LaunchedEffect
            // A run cut short by this one hands over the trail it had, which this one closes.
            val previous = glideRun?.takeIf { elapsed.floatValue < it.spanMs }?.trimmed(2)
            val next = GlideRun(item.offset.toFloat(), glideMs(rows, leadRow - 1).toFloat(), index, previous, elapsed.floatValue)
            elapsed.floatValue = 0f
            glideRun = next
            glide(listState, next, elapsed)
        }

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = anchor, bottom = maxHeight * 0.6f, start = SIDE_BLEED, end = SIDE_BLEED),
            // Drawn SIDE_BLEED wider than the room it's given on each side, the lines held back
            // by as much: the faded edges are drawn into a layer the list's size, and at the
            // list's own width a blurred line and the sung line's glow were cut off in a straight
            // edge down the left, which showed as a shadow. The lines sit where they did.
            modifier = Modifier
                .layout { measurable, constraints ->
                    val bleed = SIDE_BLEED.roundToPx()
                    val p = measurable.measure(constraints.copy(
                        minWidth = constraints.minWidth + bleed * 2,
                        maxWidth = if (constraints.hasBoundedWidth) constraints.maxWidth + bleed * 2 else constraints.maxWidth,
                    ))
                    layout((p.width - bleed * 2).coerceAtLeast(0), p.height) { p.place(-bleed, 0) }
                }
                .fillMaxSize()
                .softEdges(top = EDGE_FADE_TOP, bottom = EDGE_FADE_BOTTOM),
        ) {
            item(key = "intro") {
                val firstStart = lines.firstOrNull()?.startMs ?: 0L
                val waiting by remember(firstStart) { derivedStateOf { firstStart > 2_500 && pos() < firstStart - 300 } }
                IntroDots(visible = waiting)
            }
            itemsIndexed(rows, key = { _, row -> row.key }) { r, row ->
                Box(
                    Modifier.graphicsLayer {
                        // The rows after the one the list is heading for set off a little after
                        // one another, so the gaps open as it leaves and close as it lands.
                        translationY = glideRun?.let { trailOf(it, r + 1, elapsed.floatValue) } ?: 0f
                    },
                ) {
                when (row) {
                    is LyricRow.Line -> {
                        val i = row.index
                        val line = row.line
                        val picked = selection?.contains(i)
                        LyricLineView(
                            line = line,
                            distance = i - activeLine,
                            isActive = r == activeRow && !selecting,
                            animation = animation,
                            blurEnabled = blur && following,
                            position = clock,
                            romanized = romanized.getOrNull(i),
                            duet = duet,
                            selected = if (selecting) picked == true else null,
                            onClick = {
                                if (selecting && selection != null) {
                                    // Tap to add or drop a line, up to the card's limit.
                                    when {
                                        i in selection -> selection.remove(i)
                                        selection.size < com.opentune.ui.share.LyricCard.MAX_LINES -> selection.add(i)
                                        else -> { haptics.pattern(com.opentune.ui.components.Haptics.Pattern.OFF); return@LyricLineView }
                                    }
                                    haptics.tick()
                                } else {
                                    onSeek(line.startMs)
                                    following = true
                                }
                            },
                            // A long press starts picking lines to share; without a song to
                            // share, it lines the lyrics up with this line as before.
                            onLongClick = when {
                                selection != null -> { { if (!selecting) { haptics.press(); selection.add(i) } } }
                                onSyncLine != null -> { { onSyncLine(line.startMs); following = true } }
                                else -> null
                            },
                        )
                    }
                    is LyricRow.Gap -> GapDots(
                        visible = r == activeRow,
                        progress = { ((clock() - row.gap.startMs).toFloat() / (row.gap.endMs - row.gap.startMs)).coerceIn(0f, 1f) },
                    )
                }
                }
            }
            item(key = "credit") { Credit(source) }
        }

        AnimatedVisibility(
            visible = !following && !selecting,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
        ) {
            AssistChip(
                onClick = { following = true },
                label = { Text("Back to the music") },
                leadingIcon = { Icon(Icons.Rounded.Sync, null, Modifier.size(18.dp)) },
                colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHighest),
            )
        }
        AnimatedVisibility(
            visible = selecting,
            enter = fadeIn() + androidx.compose.animation.slideInVertically { it },
            exit = fadeOut() + androidx.compose.animation.slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
        ) {
            SelectionBar(
                count = selection?.size ?: 0,
                onCancel = { haptics.tick(); selection?.clear(); following = true },
                onShare = { haptics.press(); onShareSelection?.invoke(); following = true },
            )
        }
    }
}

/** How fast the list was gliding, kept from one line to the next. */
/**
 * Lines thin out toward the list's top and bottom edges instead of being cut
 * off along a hard line there: the list is drawn into its own layer and
 * faded out over [top] and [bottom] with a gradient mask.
 */
private fun Modifier.softEdges(top: androidx.compose.ui.unit.Dp, bottom: androidx.compose.ui.unit.Dp): Modifier =
    graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val h = size.height
            if (h <= 0f) return@drawWithContent
            val t = (top.toPx() / h).coerceIn(0f, 0.5f)
            val b = (bottom.toPx() / h).coerceIn(0f, 0.5f)
            drawRect(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    0f to Color.Transparent, t to Color.Black, (1f - b) to Color.Black, 1f to Color.Transparent,
                ),
                blendMode = androidx.compose.ui.graphics.BlendMode.DstIn,
            )
        }

/** How far a line's blur and glow may spread past the lyrics' sides. */
private val SIDE_BLEED = 24.dp
private val EDGE_FADE_TOP = 18.dp
private val EDGE_FADE_BOTTOM = 96.dp

/**
 * One move of the list to the next line: how far ([delta] px, positive when the
 * words move up), over how long, to which item, and the move it cut short (with
 * how far into that one it was), whose trail this one closes.
 */
private class GlideRun(
    val delta: Float,
    val durationMs: Float,
    val target: Int,
    val previous: GlideRun?,
    val handOffMs: Float,
) {
    /** The last trailing row lands this long after the list sets off. */
    val spanMs get() = durationMs * (1f + TRAIL_STEP * TRAIL_ROWS)

    /** This run with at most [depth] cut-short runs behind it: lines coming fast can't pile them up. */
    fun trimmed(depth: Int): GlideRun = GlideRun(delta, durationMs, target, if (depth <= 0) null else previous?.trimmed(depth - 1), handOffMs)
}

/**
 * How far behind the list item [index] runs, [elapsedMs] into [run]. Each row
 * after the target sets off [TRAIL_STEP] of the move later than the one before,
 * on the same curve as the list, so it trails by the difference between the
 * two and is exactly back in place when its own curve ends. A cut-short run's
 * trail fades out over this one on the same curve.
 */
private fun trailOf(run: GlideRun, index: Int, elapsedMs: Float): Float {
    val behind = (if (run.delta >= 0f) index - run.target else run.target - index).coerceIn(0, TRAIL_ROWS)
    val own = if (behind == 0) 0f else {
        val late = behind * TRAIL_STEP * run.durationMs
        run.delta * (GLIDE_EASING.transform((elapsedMs / run.durationMs).coerceIn(0f, 1f)) -
            GLIDE_EASING.transform(((elapsedMs - late) / run.durationMs).coerceIn(0f, 1f)))
    }
    val handed = run.previous?.let { trailOf(it, index, run.handOffMs) } ?: 0f
    return own + handed * (1f - GLIDE_EASING.transform((elapsedMs / run.durationMs).coerceIn(0f, 1f)))
}

/**
 * How long the move after row [current] takes: the quiet between its end and the
 * next row's start, kept between [GLIDE_MIN_MS] and [GLIDE_MAX_MS]. A held breath
 * gets a quick move, a long pause an unhurried one, and neither snaps nor drifts.
 */
private fun glideMs(rows: List<LyricRow>, current: Int): Long {
    val row = rows.getOrNull(current) ?: return GLIDE_MIN_MS
    val next = rows.getOrNull(current + 1) ?: return GLIDE_MIN_MS
    val end = if (row.endMs > row.startMs) row.endMs else next.startMs
    return (next.startMs - end).coerceIn(GLIDE_MIN_MS, GLIDE_MAX_MS)
}

/**
 * Moves the list along [run] on [GLIDE_EASING], publishing how far into it it is
 * for the rows' trail. Each frame aims at where the target item actually is, so
 * a row changing height mid-move (a break folding away) can't leave it short;
 * the curve's shape is kept and it lands exactly as the time runs out.
 */
private suspend fun glide(state: LazyListState, run: GlideRun, elapsed: androidx.compose.runtime.MutableFloatState) {
    val start = withFrameNanos { it }
    var done = 0f
    state.scroll {
        while (true) {
            val t = (withFrameNanos { it } - start) / 1e6f
            elapsed.floatValue = t
            val item = state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == run.target } ?: break
            val progress = GLIDE_EASING.transform((t / run.durationMs).coerceIn(0f, 1f))
            // The share of what's left that the curve covers this frame.
            val share = if (done >= 1f) 1f else ((progress - done) / (1f - done)).coerceIn(0f, 1f)
            done = progress
            val step = item.offset * share
            // Short of the step: the list is at its end.
            if (abs(scrollBy(step)) + 0.5f < abs(step) || t >= run.durationMs) break
        }
    }
    // The trailing rows finish their own curves.
    while (elapsed.floatValue < run.spanMs) elapsed.floatValue = (withFrameNanos { it } - start) / 1e6f
}

/** How long a line takes to brighten, dim or change size as the list moves to the next. */
private const val LINE_SETTLE_MS = 420

/** A quick start and a long, soft landing: the list leaves briskly and settles without a bump. */
private val GLIDE_EASING = androidx.compose.animation.core.CubicBezierEasing(0.33f, 0f, 0.1f, 1f)
/** A move never takes less than this, however close the next line… */
private const val GLIDE_MIN_MS = 320L
/** …or more than this, however long the pause before it. */
private const val GLIDE_MAX_MS = 520L
/** Each trailing row sets off this share of the move after the one above it… */
private const val TRAIL_STEP = 0.07f
/** …for this many rows; the rest move with the last of them. */
private const val TRAIL_ROWS = 4

/** One row of the synced list: a sung line, or the instrumental break after one. */
private sealed interface LyricRow {
    val startMs: Long
    /** When its singing (or its break) ends; at or before [startMs] when the source doesn't say. */
    val endMs: Long
    val key: String

    class Line(val index: Int, val line: LyricLine) : LyricRow {
        override val startMs get() = line.startMs
        override val endMs get() = line.endMs
        override val key get() = "$index:${line.startMs}"
    }

    class Gap(val gap: LyricGap) : LyricRow {
        override val startMs get() = gap.startMs
        override val endMs get() = gap.endMs
        override val key get() = "gap:${gap.afterIndex}:${gap.startMs}"
    }
}

private fun buildLyricRows(lines: List<LyricLine>): List<LyricRow> {
    val gaps = lines.instrumentalGaps().associateBy { it.afterIndex }
    return buildList {
        lines.forEachIndexed { i, line ->
            add(LyricRow.Line(i, line))
            gaps[i]?.let { add(LyricRow.Gap(it)) }
        }
    }
}

/**
 * Three dots for an instrumental break. They fill in one after another as the
 * break runs out, so you can see the next line coming, and breathe while they wait.
 *
 * The row keeps its height whether the dots show or not, and they only fade:
 * a row growing and shrinking moved the lines under the scroll's own glide,
 * and the line after a break shook and settled instead of arriving smoothly.
 */
@Composable
private fun GapDots(visible: Boolean, progress: () -> Float) {
    val shown = animateFloatAsState(if (visible) 1f else 0f, tween(if (visible) 420 else 260), label = "gapShown")
    // The breathing runs only while the dots can be seen: every break's row in the list kept a
    // frame loop going for dots at zero opacity, and kept the screen redrawing while paused.
    val breathing by remember { derivedStateOf { shown.value > 0f } }
    val breath = if (breathing) {
        rememberInfiniteTransition(label = "gap").animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(1_200), RepeatMode.Reverse), label = "breath")
    } else remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
    val ink = MaterialTheme.colorScheme.onSurface
    Row(
        Modifier
            .padding(vertical = 18.dp)
            // Read while drawing only, so the breathing never recomposes the row.
            .graphicsLayer { scaleX = breath.value; scaleY = breath.value; alpha = shown.value; transformOrigin = TransformOrigin(0f, 0.5f) },
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        repeat(3) { i ->
            Box(
                Modifier
                    .size(14.dp)
                    .drawWithContent {
                        // Each dot takes a third of the break to light, from dim to full.
                        val lit = (progress() * 3f - i).coerceIn(0f, 1f)
                        drawCircle(ink.copy(alpha = 0.3f + 0.7f * lit))
                    },
            )
        }
    }
}


/** How one [LyricsAnimation] treats lines: sizes, blur per line away, and glow. */
/** How far, as a share of a row's height, a letter can reach past its row's box. */
private const val GLYPH_OVERHANG = 0.35f

/** Empty room round a blurred line inside its blur's buffer, so the blur fades out before the buffer's edge. */
private val BLUR_BLEED = 28.dp

private class LineMotion(
    val activeScale: Float,
    val inactiveScale: Float,
    val blurPerLine: Float,
    val glow: Boolean,
    val inactiveAlpha: Float,
)

private fun motionOf(animation: LyricsAnimation) = when (animation) {
    LyricsAnimation.FLUID -> LineMotion(1f, 0.97f, 1.8f, glow = false, inactiveAlpha = 0.8f)
    LyricsAnimation.KARAOKE -> LineMotion(1f, 1f, 0f, glow = true, inactiveAlpha = 0.55f)
    // The active line stays at 1.0; the others shrink more, so it still reads as zoomed
    // without scaling the current line past its box, which chopped long lines.
    LyricsAnimation.ZOOM -> LineMotion(1f, 0.84f, 1.9f, glow = false, inactiveAlpha = 0.6f)
    LyricsAnimation.MINIMAL -> LineMotion(1f, 1f, 0f, glow = false, inactiveAlpha = 0.6f)
}

@Composable
internal fun LyricLineView(
    line: LyricLine,
    distance: Int,
    isActive: Boolean,
    animation: LyricsAnimation,
    blurEnabled: Boolean,
    position: () -> Long,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    romanized: String? = null,
    duet: Boolean = false,
    /** While lines are being picked to share: whether this one is. Null otherwise. */
    selected: Boolean? = null,
) {
    val motion = motionOf(animation)
    val bright = MaterialTheme.colorScheme.onSurface
    val dim = bright.copy(alpha = 0.45f)
    val picking = selected != null
    val scale by animateFloatAsState(
        if (isActive || picking) motion.activeScale else motion.inactiveScale,
        // On the glide's own curve and time, so the size, the fade and the move are one motion.
        tween(LINE_SETTLE_MS, easing = GLIDE_EASING),
        label = "lineScale",
    )
    val alpha by animateFloatAsState(
        when {
            picking -> if (selected == true) 1f else 0.6f
            isActive -> 1f
            else -> (motion.inactiveAlpha - 0.06f * (minOf(abs(distance), 5) - 1) - if (distance < 0) 0.1f else 0f).coerceAtLeast(0.18f)
        },
        tween(if (animation == LyricsAnimation.MINIMAL) 200 else LINE_SETTLE_MS, easing = GLIDE_EASING),
        label = "lineAlpha",
    )
    // Set, not animated, and read only while drawing (below): an animated blur was worked
    // out again on every frame for every visible line each time the song moved to the next
    // one, which is what made the page stutter. Now each line's blur is redrawn once per
    // line change, while its fade and size still animate, which are cheap.
    val blur = androidx.compose.runtime.rememberUpdatedState(
        if (!blurEnabled || isActive || picking) 0.dp else (minOf(abs(distance), 6) * motion.blurPerLine).dp,
    )
    // Picking lines, each sits on its own card, the picked ones a shade lighter.
    val card by androidx.compose.animation.animateColorAsState(
        when (selected) {
            null -> Color.Transparent
            true -> bright.copy(alpha = 0.16f)
            false -> bright.copy(alpha = 0.06f)
        },
        tween(220),
        label = "lineCard",
    )
    val ui by AppSettings.ui.collectAsState()
    val centred = ui.lyricsAlign == LyricsAlign.CENTER
    // In a duet the second voice's lines sit on the right and lines sung together in the middle.
    val align = when {
        !duet || centred -> if (centred) TextAlign.Center else TextAlign.Start
        line.voice == VOICE_SECOND -> TextAlign.End
        line.voice == VOICE_TOGETHER -> TextAlign.Center
        else -> TextAlign.Start
    }
    // A right-to-left line starts at the right: Start and End swap sides, and it sweeps leftwards.
    val rtl = remember(line) { com.opentune.data.lyrics.readsRightToLeft(line) }
    val origin = when (align) { TextAlign.Center -> 0.5f; TextAlign.End -> if (rtl) 0f else 1f; else -> if (rtl) 1f else 0f }
    val base = lyricsStyle().copy(textAlign = align, textDirection = if (rtl) TextDirection.Rtl else TextDirection.Ltr)
    val style = if ((motion.glow || ui.lyricsGlow) && isActive) base.copy(shadow = Shadow(bright.copy(alpha = 0.55f), blurRadius = 24f)) else base
    val text = remember(line) { if (line.words.isEmpty()) line.text else line.words.joinToString("") { it.text } }
    val layout = remember(text) { mutableStateOf<TextLayoutResult?>(null) }
    // Where each word sits, worked out once per layout rather than every frame.
    // A word's trailing space is left out, and a word that still runs across a
    // wrap gets one box per row: a single box for the word that ends the first
    // row would span both rows edge to edge and dim the whole line until sung.
    // Words light one by one only where the source timed them. A line timed as a
    // whole lights all at once, on time, rather than sweeping on guessed word times.
    val sweep = isActive && line.wordSynced && line.words.isNotEmpty()
    val cardPad by animateDpAsState(if (picking) 14.dp else 0.dp, tween(220), label = "cardPad")
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = cardPad / 5)
            // The card is drawn in its shape, not clipped to it: a clip would cut a
            // blurred line's soft edge into a hard box.
            .background(card, MaterialTheme.shapes.medium)
            .combinedClickable(remember { MutableInteractionSource() }, indication = com.opentune.ui.components.FocusRing(MaterialTheme.shapes.medium), onLongClick = onLongClick, onClick = onClick)
            .padding(vertical = 10.dp, horizontal = cardPad)
            // The fade and the size sit outside the blur. Inside it, each frame of a line
            // change's 420 ms fade changed the blurred layer's content, so every visible
            // line was blurred again on every frame of every line change: the stutter as
            // the song moved on. Outside, the blurred picture is kept and only scaled and
            // faded, which costs next to nothing. The fade is still applied to what's
            // drawn (ModulateAlpha), with no buffer of its own to clip the blur's edge.
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                this.alpha = alpha
                compositingStrategy = CompositingStrategy.ModulateAlpha
                transformOrigin = TransformOrigin(origin, 0.5f)
            }
            // Android blurs a layer inside a buffer its own size, so whatever the
            // blur would spread past the line was cut off in a hard box. The
            // blurred layer is made BLUR_BLEED larger on every side, with that
            // much empty space round the words, and laid out as if it weren't:
            // the line takes the same room and wraps the same, and its blur fades
            // to nothing inside the buffer. Inside, the line's fade is applied to
            // each glyph drawn (ModulateAlpha), with no buffer of its own to clip.
            .then(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && blurEnabled) {
                    Modifier
                        .layout { measurable, constraints ->
                            val bleed = BLUR_BLEED.roundToPx()
                            val grown = constraints.copy(
                                minWidth = constraints.minWidth + bleed * 2,
                                maxWidth = if (constraints.hasBoundedWidth) constraints.maxWidth + bleed * 2 else constraints.maxWidth,
                                minHeight = constraints.minHeight + bleed * 2,
                                maxHeight = if (constraints.hasBoundedHeight) constraints.maxHeight + bleed * 2 else constraints.maxHeight,
                            )
                            val p = measurable.measure(grown)
                            layout((p.width - bleed * 2).coerceAtLeast(0), (p.height - bleed * 2).coerceAtLeast(0)) { p.place(-bleed, -bleed) }
                        }
                        .graphicsLayer {
                            // Whole pixels only: a radius that changes by a fraction each frame
                            // makes the blur redraw for nothing a viewer could see.
                            val radius = kotlin.math.round(blur.value.toPx())
                            renderEffect = if (radius >= 1f) androidx.compose.ui.graphics.BlurEffect(radius, radius, androidx.compose.ui.graphics.TileMode.Decal) else null
                            clip = false
                        }
                        .padding(BLUR_BLEED)
                } else Modifier,
            ),
    ) {
        // Keep one text node and one shaping/layout result through activation. Replacing
        // the node made the first active frame draw without its word mask, then flash dim.
        Text(
            text = text,
            style = style,
            color = if (isActive) bright else dim,
            onTextLayout = { layout.value = it },
            modifier = Modifier.fillMaxWidth()
                // The sung line's glow spreads past its words, and the offscreen buffer the word
                // sweep is drawn in is only as big as the text: the glow stopped at its edge in a
                // dark line. The buffer is GLOW_BLEED larger on every side, laid out as if it weren't.
                .layout { measurable, constraints ->
                    val bleed = GLOW_BLEED.roundToPx()
                    val p = measurable.measure(constraints.copy(
                        minWidth = constraints.minWidth + bleed * 2,
                        maxWidth = if (constraints.hasBoundedWidth) constraints.maxWidth + bleed * 2 else constraints.maxWidth,
                        minHeight = constraints.minHeight + bleed * 2,
                        maxHeight = if (constraints.hasBoundedHeight) constraints.maxHeight + bleed * 2 else constraints.maxHeight,
                    ))
                    layout((p.width - bleed * 2).coerceAtLeast(0), (p.height - bleed * 2).coerceAtLeast(0)) { p.place(-bleed, -bleed) }
                }
                // Only the line being swept needs a buffer of its own, for the sweep to dim
                // its words and nothing behind them; every other line drew through one for
                // nothing, a dozen extra buffers composited on every frame.
                .graphicsLayer { compositingStrategy = if (sweep) CompositingStrategy.Offscreen else CompositingStrategy.Auto }
                .padding(GLOW_BLEED)
                .drawWithCache {
                    val boxes = wordBoxesOf(layout.value, line, text)
                    onDrawWithContent {
                        drawContent()
                        if (sweep) sweepDim(line, boxes, position(), 0.4f, rtl)
                    }
                }
                // The words (and the sung line's glow) recorded once in a layer of their own:
                // the sweep above redraws every frame, and without this the text and its
                // blurred glow were laid down again with it each time.
                .graphicsLayer(),
        )
        // Backing vocals, smaller and softer, under the line they're sung with.
        line.background?.let {
            Text(
                it,
                style = base.copy(fontSize = base.fontSize * 0.62f, lineHeight = base.lineHeight * 0.62f),
                color = (if (isActive) bright else dim).copy(alpha = if (isActive) 0.6f else 0.25f),
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
            )
        }
        romanized?.let {
            Text(
                it,
                style = base.copy(fontSize = base.fontSize * 0.5f, lineHeight = base.lineHeight * 0.55f, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium),
                color = (if (isActive) bright else dim).copy(alpha = if (isActive) 0.75f else 0.3f),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            )
        }
    }
}

/** Room round a line's words for its glow to fade out in (the glow's blur is 24 px). */
private val GLOW_BLEED = 16.dp

/** Where each of [line]'s words sits in [layout] of [text]: one box per row a word covers, trailing space left out. */
internal fun wordBoxesOf(layout: TextLayoutResult?, line: LyricLine, text: String): List<List<Rect>> {
    val l = layout ?: return emptyList()
    var start = 0
    // Where the word before ended on each row: a word's box reaches back to it, so the gap
    // between them (where a j's hook or a slanted letter's foot reaches) is lit with the
    // word that follows, not left lit from the start.
    val previousEdge = HashMap<Int, Float>()
    val rtl = com.opentune.data.lyrics.readsRightToLeft(line)
    return line.words.map { w ->
        val end = (start + w.text.length).coerceAtMost(text.length)
        var visibleEnd = end
        while (visibleEnd > start && text[visibleEnd - 1].isWhitespace()) visibleEnd--
        // Past the last row shown (an ellipsized preview), there's nothing to light.
        val shown = if (l.lineCount > 0) l.getLineEnd(l.lineCount - 1, visibleEnd = true) else 0
        visibleEnd = minOf(visibleEnd, shown)
        val boxes = if (visibleEnd <= start) emptyList() else {
            val first = l.getLineForOffset(start)
            val last = l.getLineForOffset(visibleEnd - 1)
            (first..last).mapNotNull { row ->
                val from = maxOf(start, l.getLineStart(row))
                val to = minOf(visibleEnd, l.getLineEnd(row, visibleEnd = true))
                if (to <= from) return@mapNotNull null
                val box = l.getPathForRange(from, to).getBounds()
                // Glyphs reach past their row: the dots of i and j above the first
                // row (the line height is set tight), tails below the last, and a
                // j's hook left of a row's first word. The box takes them in where
                // no other word can be, so no part of a letter stays lit early.
                val pad = box.height * GLYPH_OVERHANG
                val before = previousEdge[row]
                previousEdge[row] = if (rtl) box.left else box.right
                Rect(
                    left = if (rtl) {
                        if (to == l.getLineEnd(row, visibleEnd = true)) box.left - pad else box.left
                    } else if (from == l.getLineStart(row)) box.left - pad else minOf(box.left, before ?: box.left),
                    top = if (row == 0) box.top - pad else box.top,
                    right = if (rtl) {
                        if (from == l.getLineStart(row)) box.right + pad else maxOf(box.right, before ?: box.right)
                    } else if (to == l.getLineEnd(row, visibleEnd = true)) box.right + pad else box.right,
                    bottom = if (row == l.lineCount - 1) box.bottom + pad else box.bottom,
                )
            }
        }
        start = end
        boxes
    }
}

/**
 * One line lit as it's sung, for the player's one-line preview: word by word
 * where the source timed the words, the whole line at once where it only timed
 * lines, and dimmed through an instrumental break after it.
 */
@Composable
internal fun SungLine(line: LyricLine, position: () -> Long, style: androidx.compose.ui.text.TextStyle, modifier: Modifier = Modifier) {
    val bright = MaterialTheme.colorScheme.onSurface
    val text = remember(line) { if (line.words.isEmpty()) line.text else line.words.joinToString("") { it.text } }
    val layout = remember(text) { mutableStateOf<TextLayoutResult?>(null) }
    val rtl = remember(line) { com.opentune.data.lyrics.readsRightToLeft(line) }
    Text(
        text,
        style = style,
        color = bright,
        maxLines = 1,
        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        onTextLayout = { layout.value = it },
        modifier = modifier
            .graphicsLayer { compositingStrategy = if (line.wordSynced) CompositingStrategy.Offscreen else CompositingStrategy.Auto }
            .drawWithCache {
                val boxes = wordBoxesOf(layout.value, line, text)
                onDrawWithContent {
                    drawContent()
                    if (line.wordSynced) sweepDim(line, boxes, position(), 0.55f, rtl)
                }
            }
            // The words in a layer of their own, so the sweep's per-frame redraw doesn't lay them down again.
            .graphicsLayer(),
    )
}

/**
 * Sweeps word by word along the line as it's sung, cutting the alpha of the
 * part not reached yet by [removal] (a fraction of 0..1, fully removed at 1),
 * so the whole active line stays readable and lifts a little as each word
 * lands. A word split over two rows fills its first piece, then its second.
 * Done at draw time, so the line isn't measured again every frame.
 */
private fun DrawScope.sweepDim(line: LyricLine, boxes: List<List<Rect>>, positionMs: Long, removal: Float, rtl: Boolean = false) {
    // A wide soft edge, as BitChord's: the light eases across each word rather than wiping it.
    val feather = 26.dp.toPx()
    line.words.forEachIndexed { i, word ->
        val pieces = boxes.getOrNull(i) ?: return@forEachIndexed
        if (pieces.isEmpty()) return@forEachIndexed
        val span = (word.endMs - word.startMs).coerceAtLeast(1)
        // Even through the word: an eased fill rushed the start and lagged the end, off the singing.
        val t = ((positionMs - word.startMs).toFloat() / span).coerceIn(0f, 1f)
        if (t >= 1f) return@forEachIndexed
        val total = pieces.sumOf { it.width.toDouble() }.toFloat().coerceAtLeast(1f)
        var before = 0f
        pieces.forEach { box ->
            val pieceT = ((t * total - before) / box.width.coerceAtLeast(1f)).coerceIn(0f, 1f)
            before += box.width
            if (pieceT >= 1f || box.isEmpty) return@forEach
            val travel = (box.width + feather) * pieceT
            val litX = if (rtl) box.right - travel else box.left + travel
            drawRect(
                brush = if (rtl) Brush.horizontalGradient(
                    0f to Color.Black.copy(alpha = removal),
                    1f to Color.Transparent,
                    startX = litX,
                    endX = litX + feather,
                ) else Brush.horizontalGradient(
                    0f to Color.Transparent,
                    1f to Color.Black.copy(alpha = removal),
                    startX = litX - feather,
                    endX = litX,
                ),
                topLeft = Offset(box.left, box.top),
                size = Size(box.width, box.height),
                blendMode = BlendMode.DstOut,
            )
        }
    }
}

/** While the sources are asked: a small pill saying the lyrics are on their way, with a turning mark. */
@Composable
internal fun SettingUpBadge(modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier
            .clip(CircleShape)
            .background(colors.onSurface.copy(alpha = 0.10f))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        androidx.compose.material3.CircularProgressIndicator(
            Modifier.size(12.dp), color = colors.onSurface, strokeWidth = 1.5.dp, trackColor = colors.onSurface.copy(alpha = 0.2f),
        )
        androidx.compose.foundation.layout.Spacer(Modifier.size(8.dp))
        Text("Setting up the lyrics…", style = MaterialTheme.typography.labelLarge, color = colors.onSurface.copy(alpha = 0.85f))
    }
}

/** Three dots breathing in sequence while an intro plays; like [GapDots], they fade but keep their room. */
@Composable
private fun IntroDots(visible: Boolean) {
    val shown = animateFloatAsState(if (visible) 1f else 0f, tween(if (visible) 420 else 260), label = "introShown")
    // Pulsing only while they can be seen; the intro row stays in the list after the singing starts.
    val pulsing by remember { derivedStateOf { shown.value > 0f } }
    Row(Modifier.padding(vertical = 18.dp).graphicsLayer { alpha = shown.value }, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        val transition = if (pulsing) rememberInfiniteTransition(label = "intro") else null
        repeat(3) { i ->
            val s = transition?.animateFloat(
                0.6f,
                1f,
                infiniteRepeatable(tween(600, delayMillis = i * 200), RepeatMode.Reverse),
                label = "dot",
            ) ?: remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
            Box(
                Modifier
                    .size(14.dp)
                    .graphicsLayer { scaleX = s.value; scaleY = s.value; alpha = s.value }
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurface),
            )
        }
    }
}

@Composable
private fun Credit(source: String) {
    Spacer(Modifier.height(24.dp))
    Text(
        com.opentune.i18n.Tr.f("Lyrics from {0}", source),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text(
        "Long-press a line to share it on a card. Out of time? Pick the line being sung and tap sync.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        modifier = Modifier.padding(top = 4.dp),
    )
}

private const val RESUME_FOLLOW_MS = 3_000L
/** Where the current line sits, as a share of the height from the top: room for one line above it. */
/** Where the active line sits, down from the top: high, with only a sliver of the line before it showing. */
private const val LINE_ANCHOR = 0.085f
/** How far ahead of its timestamp a line lights up. */
private const val LINE_LEAD_MS = 150L

/** The lyrics style at the size and alignment chosen in Settings. */
@Composable
private fun lyricsStyle(): androidx.compose.ui.text.TextStyle {
    val ui = AppSettings.ui.collectAsState().value
    val scale = ui.lyricsTextScale
    return LyricsTextStyle.copy(
        fontFamily = MaterialTheme.typography.bodyLarge.fontFamily,
        fontSize = LyricsTextStyle.fontSize * scale,
        lineHeight = LyricsTextStyle.lineHeight * scale,
        textAlign = if (ui.lyricsAlign == LyricsAlign.CENTER) TextAlign.Center else TextAlign.Start,
    )
}
